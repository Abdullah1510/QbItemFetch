# Enter Database Name in .env file

# DB_NAME=YOUR DATABASE NAME

# Then Start qb_search_server-win.exe